#!/usr/bin/env bash
set -euo pipefail

ENROLLMENT_FILE=""
PACKAGE_PATH=""
FORCE_REENROLL=0
KEEP_ENROLLMENT_FILE=0
CONNECTION_TIMEOUT_SECONDS=180

usage() {
  cat <<'USAGE'
Usage:
  sudo bash Install-CyrpWazuhFromEnrollmentFile.sh --enrollment-file FILE [--package-path FILE] [--force-reenroll]

This script configures an existing Wazuh Linux Agent or installs a local .deb/.rpm package when --package-path is supplied.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --enrollment-file)
      ENROLLMENT_FILE="${2:-}"; shift 2 ;;
    --package-path)
      PACKAGE_PATH="${2:-}"; shift 2 ;;
    --force-reenroll)
      FORCE_REENROLL=1; shift ;;
    --keep-enrollment-file)
      KEEP_ENROLLMENT_FILE=1; shift ;;
    --connection-timeout)
      CONNECTION_TIMEOUT_SECONDS="${2:-180}"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run this script with sudo/root." >&2
  exit 1
fi

if [[ -z "$ENROLLMENT_FILE" || ! -f "$ENROLLMENT_FILE" ]]; then
  echo "--enrollment-file is required and must point to an existing file." >&2
  exit 1
fi

command -v python3 >/dev/null 2>&1 || { echo "python3 is required." >&2; exit 1; }

eval "$(python3 - "$ENROLLMENT_FILE" <<'PY'
import json
import shlex
import sys

data = json.load(open(sys.argv[1], encoding="utf-8"))
required = [
    "deviceId",
    "installationId",
    "agentId",
    "agentName",
    "managerAddress",
    "managerPort",
    "protocol",
    "agentToken",
    "clientKey",
]

for key in required:
    if key not in data or data[key] in (None, ""):
        raise SystemExit(f"Enrollment file is missing property: {key}")

for key, env in [
    ("deviceId", "DEVICE_ID"),
    ("installationId", "INSTALLATION_ID"),
    ("agentId", "AGENT_ID"),
    ("agentName", "AGENT_NAME"),
    ("managerAddress", "MANAGER_ADDRESS"),
    ("managerPort", "MANAGER_PORT"),
    ("protocol", "PROTOCOL"),
    ("agentToken", "AGENT_TOKEN"),
    ("clientKey", "CLIENT_KEY"),
]:
    print(f"{env}={shlex.quote(str(data[key]))}")
PY
)"

PROTOCOL="$(printf '%s' "$PROTOCOL" | tr '[:upper:]' '[:lower:]')"

if [[ "$PROTOCOL" != "tcp" && "$PROTOCOL" != "udp" ]]; then
  echo "Unsupported Wazuh protocol: $PROTOCOL" >&2
  exit 1
fi

if [[ "$PROTOCOL" == "tcp" ]]; then
  python3 - "$MANAGER_ADDRESS" "$MANAGER_PORT" <<'PY'
import socket
import sys

host = sys.argv[1]
port = int(sys.argv[2])

sock = socket.socket()
sock.settimeout(5)

try:
    sock.connect((host, port))
except Exception as exc:
    raise SystemExit(f"Cannot reach Wazuh manager at {host}:{port} over TCP. No local files were changed. Error: {exc}")
finally:
    sock.close()
PY
else
  echo "Warning: UDP connectivity cannot be confirmed by the bootstrapper."
fi

if [[ ! -x /var/ossec/bin/manage_agents || ! -f /var/ossec/etc/ossec.conf ]]; then
  if [[ -n "$PACKAGE_PATH" ]]; then
    if [[ ! -f "$PACKAGE_PATH" ]]; then
      echo "Package path does not exist: $PACKAGE_PATH" >&2
      exit 1
    fi

    case "$PACKAGE_PATH" in
      *.deb)
        dpkg -i "$PACKAGE_PATH" || apt-get -f install -y ;;
      *.rpm)
        if command -v rpm >/dev/null 2>&1; then
          rpm -Uvh "$PACKAGE_PATH"
        else
          echo "rpm command was not found." >&2
          exit 1
        fi ;;
      *)
        echo "Unsupported package type. Use .deb or .rpm." >&2
        exit 1 ;;
    esac
  else
    echo "Wazuh Agent is not installed. Install wazuh-agent first or pass --package-path with a .deb/.rpm package." >&2
    exit 1
  fi
fi

if [[ ! -x /var/ossec/bin/manage_agents || ! -f /var/ossec/etc/ossec.conf ]]; then
  echo "Wazuh Agent files were not found after package installation." >&2
  exit 1
fi

SERVICE_NAME=""
if systemctl list-unit-files | grep -q '^wazuh-agent\.service'; then
  SERVICE_NAME="wazuh-agent"
elif systemctl list-unit-files | grep -q '^wazuh\.service'; then
  SERVICE_NAME="wazuh"
fi

if [[ -z "$SERVICE_NAME" ]]; then
  echo "Wazuh Agent systemd service was not found." >&2
  exit 1
fi

systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true

BACKUP_DIR="/var/backups/cyrp/$(date -u +%Y%m%d-%H%M%S)"
STATE_DIR="/var/lib/cyrp/state"
SECRET_DIR="/var/lib/cyrp/secrets"
mkdir -p "$BACKUP_DIR" "$STATE_DIR" "$SECRET_DIR"
chmod 700 /var/lib/cyrp "$STATE_DIR" "$SECRET_DIR" 2>/dev/null || true

cp -a /var/ossec/etc/ossec.conf "$BACKUP_DIR/ossec.conf"

EXISTING_CLIENT_KEY=""
if [[ -f /var/ossec/etc/client.keys ]]; then
  cp -a /var/ossec/etc/client.keys "$BACKUP_DIR/client.keys"
  EXISTING_CLIENT_KEY="$(tr -d '\r\n' < /var/ossec/etc/client.keys)"
fi

if [[ -n "$EXISTING_CLIENT_KEY" && "$EXISTING_CLIENT_KEY" != "$CLIENT_KEY" && "$FORCE_REENROLL" -ne 1 ]]; then
  EXISTING_ID="$(printf '%s' "$EXISTING_CLIENT_KEY" | awk '{print $1 "/" $2}')"
  echo "This endpoint is already enrolled as $EXISTING_ID. Re-run with --force-reenroll only when replacing that identity is intentional." >&2
  exit 1
fi

python3 - "$MANAGER_ADDRESS" "$MANAGER_PORT" "$PROTOCOL" <<'PY'
import re
import sys
from pathlib import Path
from xml.sax.saxutils import escape

manager_address, manager_port, protocol = sys.argv[1:4]
path = Path("/var/ossec/etc/ossec.conf")
content = path.read_text(encoding="utf-8", errors="replace")

server_block = f"""  <server>
    <address>{escape(manager_address)}</address>
    <port>{int(manager_port)}</port>
    <protocol>{escape(protocol)}</protocol>
  </server>
"""

enrollment_block = """  <enrollment>
    <enabled>no</enabled>
  </enrollment>
"""

client_match = re.search(r"<client\b[^>]*>.*?</client>", content, flags=re.I | re.S)

if client_match:
    client = client_match.group(0)

    if re.search(r"<server\b[^>]*>.*?</server>", client, flags=re.I | re.S):
        client = re.sub(r"<server\b[^>]*>.*?</server>", server_block.rstrip(), client, count=1, flags=re.I | re.S)
    else:
        client = re.sub(r"</client>", server_block + "</client>", client, count=1, flags=re.I)

    if re.search(r"<enrollment\b[^>]*>.*?</enrollment>", client, flags=re.I | re.S):
        def patch_enrollment(match):
            block = match.group(0)
            if re.search(r"<enabled\b[^>]*>.*?</enabled>", block, flags=re.I | re.S):
                return re.sub(r"<enabled\b[^>]*>.*?</enabled>", "<enabled>no</enabled>", block, count=1, flags=re.I | re.S)
            return re.sub(r"</enrollment>", "  <enabled>no</enabled>\n</enrollment>", block, count=1, flags=re.I)
        client = re.sub(r"<enrollment\b[^>]*>.*?</enrollment>", patch_enrollment, client, count=1, flags=re.I | re.S)
    else:
        client = re.sub(r"</client>", enrollment_block + "</client>", client, count=1, flags=re.I)

    content = content[:client_match.start()] + client + content[client_match.end():]
else:
    client = "<client>\n" + server_block + enrollment_block + "</client>\n"
    if not re.search(r"</ossec_config>", content, flags=re.I):
        raise SystemExit("The Wazuh ossec.conf file has no closing ossec_config element.")
    content = re.sub(r"</ossec_config>", client + "</ossec_config>", content, count=1, flags=re.I)

path.write_text(content, encoding="utf-8")
PY

if [[ "$EXISTING_CLIENT_KEY" != "$CLIENT_KEY" ]]; then
  echo "Importing Wazuh client key for Agent $AGENT_ID ($AGENT_NAME)..."
  rm -f /var/ossec/etc/client.keys
  printf '%s\n' "$CLIENT_KEY" | /var/ossec/bin/manage_agents -i >/tmp/cyrp-manage-agents.out 2>&1 || {
    cat /tmp/cyrp-manage-agents.out >&2
    exit 1
  }

  IMPORTED_CLIENT_KEY="$(tr -d '\r\n' < /var/ossec/etc/client.keys)"

  if [[ "$IMPORTED_CLIENT_KEY" != "$CLIENT_KEY" ]]; then
    echo "manage_agents completed but client.keys does not match the intended CYRP enrollment key." >&2
    exit 1
  fi
else
  echo "The intended Wazuh client key is already installed. Skipping key import."
fi

printf '%s' "$AGENT_TOKEN" > "$SECRET_DIR/agent-token"
chmod 600 "$SECRET_DIR/agent-token"

python3 - "$DEVICE_ID" "$INSTALLATION_ID" "$AGENT_ID" "$AGENT_NAME" "$MANAGER_ADDRESS" "$MANAGER_PORT" "$PROTOCOL" <<'PY'
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

device_id, installation_id, agent_id, agent_name, manager_address, manager_port, protocol = sys.argv[1:8]
state = {
    "version": 1,
    "deviceId": device_id,
    "installationId": installation_id,
    "wazuhAgentId": agent_id,
    "wazuhAgentName": agent_name,
    "managerAddress": manager_address,
    "managerPort": int(manager_port),
    "protocol": protocol,
    "configuredAt": datetime.now(timezone.utc).isoformat(),
    "agentTokenPath": "/var/lib/cyrp/secrets/agent-token",
}
path = Path("/var/lib/cyrp/state/bootstrapper-state.json")
path.write_text(json.dumps(state, indent=2), encoding="utf-8")
path.chmod(0o600)
PY

LOG_PATH="/var/ossec/logs/ossec.log"
INITIAL_SIZE=0
if [[ -f "$LOG_PATH" ]]; then
  INITIAL_SIZE="$(stat -c%s "$LOG_PATH" 2>/dev/null || echo 0)"
fi

systemctl start "$SERVICE_NAME"

DEADLINE=$((SECONDS + CONNECTION_TIMEOUT_SECONDS))
CONNECTED=0
LAST_ERROR=""

while [[ $SECONDS -lt $DEADLINE ]]; do
  if ! systemctl is-active --quiet "$SERVICE_NAME"; then
    echo "The Wazuh Agent service stopped while waiting for a manager connection." >&2
    exit 1
  fi

  if [[ -f "$LOG_PATH" ]]; then
    NEW_LOG="$(tail -c +"$((INITIAL_SIZE + 1))" "$LOG_PATH" 2>/dev/null || true)"

    if printf '%s\n' "$NEW_LOG" | grep -qi 'Connected to the server'; then
      CONNECTED=1
      break
    fi

    LAST_ERROR="$(printf '%s\n' "$NEW_LOG" | grep -Ei 'Unable to connect|Authentication error|Wrong key|corrupt payload|Invalid key' | tail -n 1 || true)"
  fi

  sleep 5
done

if [[ "$CONNECTED" -ne 1 ]]; then
  [[ -n "$LAST_ERROR" ]] && echo "Latest Wazuh connection error: $LAST_ERROR" >&2
  echo "Wazuh Agent is running but did not confirm a manager connection within $CONNECTION_TIMEOUT_SECONDS seconds. Enrollment file was retained for retry. Log: $LOG_PATH" >&2
  exit 1
fi

if [[ "$KEEP_ENROLLMENT_FILE" -ne 1 ]]; then
  rm -f "$ENROLLMENT_FILE"
fi

cat <<EOF
Success: true
DeviceId: $DEVICE_ID
WazuhAgentId: $AGENT_ID
WazuhAgentName: $AGENT_NAME
ManagerAddress: $MANAGER_ADDRESS
ManagerPort: $MANAGER_PORT
Protocol: $PROTOCOL
ServiceName: $SERVICE_NAME
BackupDirectory: $BACKUP_DIR
EOF
