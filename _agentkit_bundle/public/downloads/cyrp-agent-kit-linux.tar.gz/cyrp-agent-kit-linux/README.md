# CYRP Agent Kit for Linux

This kit enrolls a Linux endpoint into CYRP/Wazuh using a one-time enrollment code from User Portal.

Supported target: systemd Linux with the official Wazuh Agent layout under `/var/ossec`.

## Recommended command from User Portal

```bash
cd ~/Downloads
tar -xzf cyrp-agent-kit-linux.tar.gz
sudo bash ./cyrp-agent-kit-linux/Invoke-CyrpWazuhBootstrapper.sh \
  --backend-base-url "http://<CYRP_API_HOST>:3001/api/v1" \
  --enrollment-code "<ONE_TIME_CODE>"
```

If Wazuh Agent is not already installed, either install it first or pass a local package:

```bash
sudo bash ./cyrp-agent-kit-linux/Invoke-CyrpWazuhBootstrapper.sh \
  --backend-base-url "http://<CYRP_API_HOST>:3001/api/v1" \
  --enrollment-code "<ONE_TIME_CODE>" \
  --package-path "./wazuh-agent.deb"
```

For RPM based distributions:

```bash
sudo bash ./cyrp-agent-kit-linux/Invoke-CyrpWazuhBootstrapper.sh \
  --backend-base-url "http://<CYRP_API_HOST>:3001/api/v1" \
  --enrollment-code "<ONE_TIME_CODE>" \
  --package-path "./wazuh-agent.rpm"
```

## Important behavior

- The endpoint does not receive Wazuh API or Indexer credentials.
- The script stores a stable installation id at `/var/lib/cyrp/state/installation-id.txt`.
- The agent metadata sent to CYRP uses `agentVersion = wazuh-linux-agentkit`.
- Wazuh automatic enrollment is explicitly disabled in `/var/ossec/etc/ossec.conf`.
- Existing `/var/ossec/etc/client.keys` is not replaced unless `--force-reenroll` is provided.
- On configuration failure, the pending enrollment file is retained under `/var/lib/cyrp/pending/`.

## Verify

```bash
sudo bash ./cyrp-agent-kit-linux/Test-CyrpWazuhAgent.sh
```
