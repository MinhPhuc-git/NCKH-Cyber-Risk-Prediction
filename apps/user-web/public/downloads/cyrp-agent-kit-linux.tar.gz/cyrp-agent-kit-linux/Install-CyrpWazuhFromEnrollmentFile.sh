#!/usr/bin/env bash
set -euo pipefail

ENROLLMENT_FILE=""
PACKAGE_PATH=""
FORCE_REENROLL=0
KEEP_ENROLLMENT_FILE=0
CONNECTION_TIMEOUT_SECONDS=180
AUTO_INSTALL_AGENT=0
WAZUH_AGENT_VERSION=""

usage() {
  cat <<'USAGE'
Usage:
  sudo bash Install-CyrpWazuhFromEnrollmentFile.sh --enrollment-file FILE [--package-path FILE] [--auto-install-agent] [--wazuh-agent-version VERSION] [--force-reenroll]

This script configures an existing Wazuh Linux Agent, installs a local .deb/.rpm package when --package-path is
supplied, or auto-installs wazuh-agent from the official Wazuh repository when --auto-install-agent is supplied
and no Wazuh Agent is present yet. Pass --wazuh-agent-version to pin the endpoint to the manager-compatible package version.
USAGE
}

# Installs wazuh-agent from the official Wazuh package repository (packages.wazuh.com).
# Supports apt (Debian/Ubuntu), dnf/yum (RHEL/CentOS/Fedora/Rocky/Alma/Amazon Linux) and zypper (openSUSE/SLES).
install_wazuh_agent_from_official_repo() {
  local os_id="" os_id_like="" fetch=""

  if [[ -f /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    os_id="${ID:-}"
    os_id_like="${ID_LIKE:-}"
  fi

  if command -v curl >/dev/null 2>&1; then
    fetch="curl -fsSL"
  elif command -v wget >/dev/null 2>&1; then
    fetch="wget -qO-"
  else
    echo "Neither curl nor wget is available to fetch the Wazuh GPG key." >&2
    return 1
  fi

  if command -v apt-get >/dev/null 2>&1 && { [[ "$os_id" == "debian" || "$os_id" == "ubuntu" ]] || [[ "$os_id_like" == *debian* ]]; }; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y gnupg apt-transport-https ca-certificates curl
    $fetch https://packages.wazuh.com/key/GPG-KEY-WAZUH | gpg --no-default-keyring --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg --import
    chmod 644 /usr/share/keyrings/wazuh.gpg
    if ! grep -q 'packages.wazuh.com/4.x/apt/' /etc/apt/sources.list.d/wazuh.list 2>/dev/null; then
      echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" | tee -a /etc/apt/sources.list.d/wazuh.list >/dev/null
    fi
    apt-get update -y
    if [[ -n "$WAZUH_AGENT_VERSION" ]]; then
      apt-get install -y --allow-downgrades "wazuh-agent=$WAZUH_AGENT_VERSION"
      apt-mark hold wazuh-agent >/dev/null 2>&1 || true
    else
      apt-get install -y wazuh-agent
    fi
    return 0
  fi

  if command -v dnf >/dev/null 2>&1 || command -v yum >/dev/null 2>&1; then
    command -v rpm >/dev/null 2>&1 && rpm --import https://packages.wazuh.com/key/GPG-KEY-WAZUH
    cat > /etc/yum.repos.d/wazuh.repo <<'EOF'
[wazuh]
gpgcheck=1
gpgkey=https://packages.wazuh.com/key/GPG-KEY-WAZUH
enabled=1
name=EL-$releasever - Wazuh
baseurl=https://packages.wazuh.com/4.x/yum/
protect=1
EOF
    if command -v dnf >/dev/null 2>&1; then
      if [[ -n "$WAZUH_AGENT_VERSION" ]]; then
        dnf install -y "wazuh-agent-$WAZUH_AGENT_VERSION"
      else
        dnf install -y wazuh-agent
      fi
    else
      if [[ -n "$WAZUH_AGENT_VERSION" ]]; then
        yum install -y "wazuh-agent-$WAZUH_AGENT_VERSION"
      else
        yum install -y wazuh-agent
      fi
    fi
    return 0
  fi

  if command -v zypper >/dev/null 2>&1; then
    command -v rpm >/dev/null 2>&1 && rpm --import https://packages.wazuh.com/key/GPG-KEY-WAZUH
    cat > /etc/zypp/repos.d/wazuh.repo <<'EOF'
[wazuh]
gpgcheck=1
gpgkey=https://packages.wazuh.com/key/GPG-KEY-WAZUH
enabled=1
name=EL-$releasever - Wazuh
baseurl=https://packages.wazuh.com/4.x/yum/
protect=1
EOF
    zypper --non-interactive refresh
    if [[ -n "$WAZUH_AGENT_VERSION" ]]; then
      zypper --non-interactive install --oldpackage "wazuh-agent=$WAZUH_AGENT_VERSION"
    else
      zypper --non-interactive install wazuh-agent
    fi
    return 0
  fi

  echo "Could not detect a supported package manager (apt-get, dnf/yum, or zypper) for --auto-install-agent." >&2
  return 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --enrollment-file)
      ENROLLMENT_FILE="${2:-}"; shift 2 ;;
    --package-path)
      PACKAGE_PATH="${2:-}"; shift 2 ;;
    --force-reenroll)
      FORCE_REENROLL=1; shift ;;
    --keep-enrollment-file)
      KEEP_ENROLLMENT_FILE=1; shift ;;
    --auto-install-agent)
      AUTO_INSTALL_AGENT=1; shift ;;
    --wazuh-agent-version)
      WAZUH_AGENT_VERSION="${2:-}"; shift 2 ;;
    --connection-timeout)
      CONNECTION_TIMEOUT_SECONDS="${2:-180}"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run this script with sudo/root." >&2
  exit 1
fi

if [[ -z "$ENROLLMENT_FILE" || ! -f "$ENROLLMENT_FILE" ]]; then
  echo "--enrollment-file is required and must point to an existing file." >&2
  exit 1
fi

command -v python3 >/dev/null 2>&1 || { echo "python3 is required." >&2; exit 1; }

eval "$(python3 - "$ENROLLMENT_FILE" <<'PY'
import json
import shlex
import sys

data = json.load(open(sys.argv[1], encoding="utf-8"))
required = [
    "deviceId",
    "installationId",
    "agentId",
    "agentName",
    "managerAddress",
    "managerPort",
    "protocol",
    "agentToken",
    "clientKey",
]

for key in required:
    if key not in data or data[key] in (None, ""):
        raise SystemExit(f"Enrollment file is missing property: {key}")

for key, env in [
    ("deviceId", "DEVICE_ID"),
    ("installationId", "INSTALLATION_ID"),
    ("agentId", "AGENT_ID"),
    ("agentName", "AGENT_NAME"),
    ("managerAddress", "MANAGER_ADDRESS"),
    ("managerPort", "MANAGER_PORT"),
    ("protocol", "PROTOCOL"),
    ("agentToken", "AGENT_TOKEN"),
    ("clientKey", "CLIENT_KEY"),
]:
    print(f"{env}={shlex.quote(str(data[key]))}")
PY
)"

# Wazuh exports clientKey as a base64 string. manage_agents -i requires that
# base64 value as its command-line argument, while /var/ossec/etc/client.keys
# contains the decoded key line. Decode and validate once so comparisons use
# the same representation as client.keys.
EXPECTED_CLIENT_KEY_LINE="$(python3 - "$CLIENT_KEY" "$AGENT_ID" "$AGENT_NAME" <<'PY'
import base64
import binascii
import sys

client_key, expected_agent_id, expected_agent_name = sys.argv[1:4]
client_key = client_key.strip()

if not client_key:
    raise SystemExit("Enrollment clientKey is empty.")

padded = client_key + ("=" * (-len(client_key) % 4))

try:
    decoded = base64.b64decode(padded, validate=True).decode("utf-8")
except (binascii.Error, UnicodeDecodeError) as exc:
    raise SystemExit(f"Enrollment clientKey is not valid Wazuh base64 data: {exc}")

line = " ".join(decoded.strip().split())
parts = line.split(" ")

if len(parts) < 4:
    raise SystemExit("Decoded Wazuh clientKey does not contain a valid client.keys line.")

if parts[0] != expected_agent_id:
    raise SystemExit(
        f"Decoded clientKey Agent ID '{parts[0]}' does not match enrollment Agent ID '{expected_agent_id}'."
    )

if parts[1] != expected_agent_name:
    raise SystemExit(
        f"Decoded clientKey Agent name '{parts[1]}' does not match enrollment Agent name '{expected_agent_name}'."
    )

print(line)
PY
)"

PROTOCOL="$(printf '%s' "$PROTOCOL" | tr '[:upper:]' '[:lower:]')"

if [[ "$PROTOCOL" != "tcp" && "$PROTOCOL" != "udp" ]]; then
  echo "Unsupported Wazuh protocol: $PROTOCOL" >&2
  exit 1
fi

if [[ "$PROTOCOL" == "tcp" ]]; then
  python3 - "$MANAGER_ADDRESS" "$MANAGER_PORT" <<'PY'
import socket
import sys

host = sys.argv[1]
port = int(sys.argv[2])

sock = socket.socket()
sock.settimeout(5)

try:
    sock.connect((host, port))
except Exception as exc:
    raise SystemExit(f"Cannot reach Wazuh manager at {host}:{port} over TCP. No local files were changed. Error: {exc}")
finally:
    sock.close()
PY
else
  echo "Warning: UDP connectivity cannot be confirmed by the bootstrapper."
fi

if [[ ! -x /var/ossec/bin/manage_agents || ! -f /var/ossec/etc/ossec.conf ]]; then
  if [[ -n "$PACKAGE_PATH" ]]; then
    if [[ ! -f "$PACKAGE_PATH" ]]; then
      echo "Package path does not exist: $PACKAGE_PATH" >&2
      exit 1
    fi

    case "$PACKAGE_PATH" in
      *.deb)
        dpkg -i "$PACKAGE_PATH" || apt-get -f install -y ;;
      *.rpm)
        if command -v rpm >/dev/null 2>&1; then
          rpm -Uvh "$PACKAGE_PATH"
        else
          echo "rpm command was not found." >&2
          exit 1
        fi ;;
      *)
        echo "Unsupported package type. Use .deb or .rpm." >&2
        exit 1 ;;
    esac
  elif [[ "$AUTO_INSTALL_AGENT" -eq 1 ]]; then
    echo "Wazuh Agent is not installed. Auto-installing wazuh-agent from the official Wazuh repository..."
    if ! install_wazuh_agent_from_official_repo; then
      echo "Auto-install of wazuh-agent failed. Install it manually or pass --package-path with a .deb/.rpm package." >&2
      exit 1
    fi
  else
    echo "Wazuh Agent is not installed. Install wazuh-agent first, pass --package-path with a .deb/.rpm package, or pass --auto-install-agent." >&2
    exit 1
  fi
fi

if [[ ! -x /var/ossec/bin/manage_agents || ! -f /var/ossec/etc/ossec.conf ]]; then
  echo "Wazuh Agent files were not found after package installation." >&2
  exit 1
fi

get_installed_wazuh_version() {
  if command -v dpkg-query >/dev/null 2>&1; then
    dpkg-query -W -f='${Version}' wazuh-agent 2>/dev/null || true
    return
  fi

  if command -v rpm >/dev/null 2>&1; then
    rpm -q --qf '%{VERSION}-%{RELEASE}' wazuh-agent 2>/dev/null || true
    return
  fi
}

if [[ -n "$WAZUH_AGENT_VERSION" ]]; then
  INSTALLED_WAZUH_VERSION="$(get_installed_wazuh_version)"

  if [[ "$INSTALLED_WAZUH_VERSION" != "$WAZUH_AGENT_VERSION" ]]; then
    if [[ "$AUTO_INSTALL_AGENT" -ne 1 ]]; then
      echo "Installed wazuh-agent version is '${INSTALLED_WAZUH_VERSION:-unknown}', but '$WAZUH_AGENT_VERSION' is required. Re-run with --auto-install-agent so the package can be aligned." >&2
      exit 1
    fi

    echo "Aligning wazuh-agent version from '${INSTALLED_WAZUH_VERSION:-not-installed}' to '$WAZUH_AGENT_VERSION'..."
    install_wazuh_agent_from_official_repo
  fi
fi

SERVICE_MODE=""
SERVICE_NAME=""

# A newly installed package may have added a unit that systemd has not loaded yet.
if command -v systemctl >/dev/null 2>&1; then
  systemctl daemon-reload >/dev/null 2>&1 || true
fi

if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files --type=service 2>/dev/null | grep -q '^wazuh-agent\.service'; then
  SERVICE_MODE="systemd"
  SERVICE_NAME="wazuh-agent"
elif command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files --type=service 2>/dev/null | grep -q '^wazuh\.service'; then
  SERVICE_MODE="systemd"
  SERVICE_NAME="wazuh"
elif [[ -x /etc/init.d/wazuh-agent ]]; then
  SERVICE_MODE="sysv"
  SERVICE_NAME="wazuh-agent"
elif [[ -x /etc/init.d/wazuh ]]; then
  SERVICE_MODE="sysv"
  SERVICE_NAME="wazuh"
elif [[ -x /var/ossec/bin/wazuh-control ]]; then
  SERVICE_MODE="control"
  SERVICE_NAME="wazuh-control"
else
  echo "No supported Wazuh Agent service controller was found. Expected systemd, /etc/init.d/wazuh-agent, or /var/ossec/bin/wazuh-control." >&2
  exit 1
fi

agent_stop() {
  case "$SERVICE_MODE" in
    systemd) systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true ;;
    sysv) "/etc/init.d/$SERVICE_NAME" stop >/dev/null 2>&1 || true ;;
    control) /var/ossec/bin/wazuh-control stop >/dev/null 2>&1 || true ;;
  esac
}

agent_start() {
  case "$SERVICE_MODE" in
    systemd) systemctl start "$SERVICE_NAME" ;;
    sysv) "/etc/init.d/$SERVICE_NAME" start ;;
    control) /var/ossec/bin/wazuh-control start ;;
  esac
}

agent_is_active() {
  case "$SERVICE_MODE" in
    systemd) systemctl is-active --quiet "$SERVICE_NAME" ;;
    sysv)
      "/etc/init.d/$SERVICE_NAME" status >/dev/null 2>&1 ||
        /var/ossec/bin/wazuh-control status 2>/dev/null | grep -q 'wazuh-agentd is running'
      ;;
    control)
      /var/ossec/bin/wazuh-control status 2>/dev/null | grep -q 'wazuh-agentd is running'
      ;;
  esac
}

agent_status_text() {
  if agent_is_active; then
    printf 'active'
  else
    printf 'inactive'
  fi
}

agent_stop

BACKUP_DIR="/var/backups/cyrp/$(date -u +%Y%m%d-%H%M%S)"
STATE_DIR="/var/lib/cyrp/state"
SECRET_DIR="/var/lib/cyrp/secrets"
mkdir -p "$BACKUP_DIR" "$STATE_DIR" "$SECRET_DIR"
chmod 700 /var/lib/cyrp "$STATE_DIR" "$SECRET_DIR" 2>/dev/null || true

cp -a /var/ossec/etc/ossec.conf "$BACKUP_DIR/ossec.conf"

read_client_keys_line() {
  if [[ -s /var/ossec/etc/client.keys ]]; then
    awk 'NF { $1=$1; print; exit }' /var/ossec/etc/client.keys
  fi
}

restore_client_keys_backup() {
  if [[ -f "$BACKUP_DIR/client.keys" ]]; then
    cp -a "$BACKUP_DIR/client.keys" /var/ossec/etc/client.keys
  else
    rm -f /var/ossec/etc/client.keys
  fi
}

EXISTING_CLIENT_KEY_LINE=""
if [[ -f /var/ossec/etc/client.keys ]]; then
  cp -a /var/ossec/etc/client.keys "$BACKUP_DIR/client.keys"
  EXISTING_CLIENT_KEY_LINE="$(read_client_keys_line)"
fi

if [[ -n "$EXISTING_CLIENT_KEY_LINE" && "$EXISTING_CLIENT_KEY_LINE" != "$EXPECTED_CLIENT_KEY_LINE" && "$FORCE_REENROLL" -ne 1 ]]; then
  EXISTING_ID="$(printf '%s' "$EXISTING_CLIENT_KEY_LINE" | awk '{print $1 "/" $2}')"
  echo "This endpoint is already enrolled as $EXISTING_ID. Re-run with --force-reenroll only when replacing that identity is intentional." >&2
  exit 1
fi

python3 - "$MANAGER_ADDRESS" "$MANAGER_PORT" "$PROTOCOL" <<'PY'
import re
import sys
from pathlib import Path
from xml.sax.saxutils import escape

manager_address, manager_port, protocol = sys.argv[1:4]
path = Path("/var/ossec/etc/ossec.conf")
content = path.read_text(encoding="utf-8", errors="replace")

server_block = f"""  <server>
    <address>{escape(manager_address)}</address>
    <port>{int(manager_port)}</port>
    <protocol>{escape(protocol)}</protocol>
  </server>
"""

enrollment_block = """  <enrollment>
    <enabled>no</enabled>
  </enrollment>
"""

client_match = re.search(r"<client\b[^>]*>.*?</client>", content, flags=re.I | re.S)

if client_match:
    client = client_match.group(0)

    if re.search(r"<server\b[^>]*>.*?</server>", client, flags=re.I | re.S):
        client = re.sub(r"<server\b[^>]*>.*?</server>", server_block.rstrip(), client, count=1, flags=re.I | re.S)
    else:
        client = re.sub(r"</client>", server_block + "</client>", client, count=1, flags=re.I)

    if re.search(r"<enrollment\b[^>]*>.*?</enrollment>", client, flags=re.I | re.S):
        def patch_enrollment(match):
            block = match.group(0)
            if re.search(r"<enabled\b[^>]*>.*?</enabled>", block, flags=re.I | re.S):
                return re.sub(r"<enabled\b[^>]*>.*?</enabled>", "<enabled>no</enabled>", block, count=1, flags=re.I | re.S)
            return re.sub(r"</enrollment>", "  <enabled>no</enabled>\n</enrollment>", block, count=1, flags=re.I)
        client = re.sub(r"<enrollment\b[^>]*>.*?</enrollment>", patch_enrollment, client, count=1, flags=re.I | re.S)
    else:
        client = re.sub(r"</client>", enrollment_block + "</client>", client, count=1, flags=re.I)

    content = content[:client_match.start()] + client + content[client_match.end():]
else:
    client = "<client>\n" + server_block + enrollment_block + "</client>\n"
    if not re.search(r"</ossec_config>", content, flags=re.I):
        raise SystemExit("The Wazuh ossec.conf file has no closing ossec_config element.")
    content = re.sub(r"</ossec_config>", client + "</ossec_config>", content, count=1, flags=re.I)

path.write_text(content, encoding="utf-8")
PY

if [[ "$EXISTING_CLIENT_KEY_LINE" != "$EXPECTED_CLIENT_KEY_LINE" ]]; then
  echo "Importing Wazuh client key for Agent $AGENT_ID ($AGENT_NAME)..."
  rm -f /var/ossec/etc/client.keys

  # Correct non-interactive form:
  #   manage_agents -i '<base64-client-key>'
  # The previous kit incorrectly piped clientKey to stdin and invoked -i
  # without its required argument, which produced:
  #   option requires an argument -- 'i'
  if ! printf 'y\n' | /var/ossec/bin/manage_agents -i "$CLIENT_KEY" >/tmp/cyrp-manage-agents.out 2>&1; then
    cat /tmp/cyrp-manage-agents.out >&2
    restore_client_keys_backup
    echo "Wazuh client key import failed. The previous client.keys file was restored." >&2
    exit 1
  fi

  if [[ ! -s /var/ossec/etc/client.keys ]]; then
    cat /tmp/cyrp-manage-agents.out >&2
    restore_client_keys_backup
    echo "manage_agents returned without creating a non-empty client.keys file." >&2
    exit 1
  fi

  IMPORTED_CLIENT_KEY_LINE="$(read_client_keys_line)"

  if [[ "$IMPORTED_CLIENT_KEY_LINE" != "$EXPECTED_CLIENT_KEY_LINE" ]]; then
    restore_client_keys_backup
    echo "manage_agents completed, but client.keys does not match the decoded CYRP enrollment key. The previous key was restored." >&2
    exit 1
  fi

  chmod 640 /var/ossec/etc/client.keys 2>/dev/null || true
  if getent group wazuh >/dev/null 2>&1; then
    chown root:wazuh /var/ossec/etc/client.keys 2>/dev/null || true
  fi
else
  echo "The intended Wazuh client key is already installed. Skipping key import."
fi

printf '%s' "$AGENT_TOKEN" > "$SECRET_DIR/agent-token"
chmod 600 "$SECRET_DIR/agent-token"

python3 - "$DEVICE_ID" "$INSTALLATION_ID" "$AGENT_ID" "$AGENT_NAME" "$MANAGER_ADDRESS" "$MANAGER_PORT" "$PROTOCOL" <<'PY'
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

device_id, installation_id, agent_id, agent_name, manager_address, manager_port, protocol = sys.argv[1:8]
state = {
    "version": 1,
    "deviceId": device_id,
    "installationId": installation_id,
    "wazuhAgentId": agent_id,
    "wazuhAgentName": agent_name,
    "managerAddress": manager_address,
    "managerPort": int(manager_port),
    "protocol": protocol,
    "configuredAt": datetime.now(timezone.utc).isoformat(),
    "agentTokenPath": "/var/lib/cyrp/secrets/agent-token",
}
path = Path("/var/lib/cyrp/state/bootstrapper-state.json")
path.write_text(json.dumps(state, indent=2), encoding="utf-8")
path.chmod(0o600)
PY

LOG_PATH="/var/ossec/logs/ossec.log"
INITIAL_SIZE=0
if [[ -f "$LOG_PATH" ]]; then
  INITIAL_SIZE="$(stat -c%s "$LOG_PATH" 2>/dev/null || echo 0)"
fi

agent_start

DEADLINE=$((SECONDS + CONNECTION_TIMEOUT_SECONDS))
CONNECTED=0
LAST_ERROR=""

while [[ $SECONDS -lt $DEADLINE ]]; do
  if ! agent_is_active; then
    echo "The Wazuh Agent service stopped while waiting for a manager connection." >&2
    exit 1
  fi

  if [[ -f "$LOG_PATH" ]]; then
    NEW_LOG="$(tail -c +"$((INITIAL_SIZE + 1))" "$LOG_PATH" 2>/dev/null || true)"

    if printf '%s\n' "$NEW_LOG" | grep -qi 'Connected to the server'; then
      CONNECTED=1
      break
    fi

    LAST_ERROR="$(printf '%s\n' "$NEW_LOG" | grep -Ei 'Unable to connect|Authentication error|Wrong key|corrupt payload|Invalid key' | tail -n 1 || true)"
  fi

  sleep 5
done

if [[ "$CONNECTED" -ne 1 ]]; then
  [[ -n "$LAST_ERROR" ]] && echo "Latest Wazuh connection error: $LAST_ERROR" >&2
  echo "Wazuh Agent is running but did not confirm a manager connection within $CONNECTION_TIMEOUT_SECONDS seconds. Enrollment file was retained for retry. Log: $LOG_PATH" >&2
  exit 1
fi

if [[ "$KEEP_ENROLLMENT_FILE" -ne 1 ]]; then
  rm -f "$ENROLLMENT_FILE"
fi

cat <<EOF
Success: true
DeviceId: $DEVICE_ID
WazuhAgentId: $AGENT_ID
WazuhAgentName: $AGENT_NAME
ManagerAddress: $MANAGER_ADDRESS
ManagerPort: $MANAGER_PORT
Protocol: $PROTOCOL
ServiceController: $SERVICE_MODE
ServiceName: $SERVICE_NAME
ServiceStatus: $(agent_status_text)
BackupDirectory: $BACKUP_DIR
EOF
