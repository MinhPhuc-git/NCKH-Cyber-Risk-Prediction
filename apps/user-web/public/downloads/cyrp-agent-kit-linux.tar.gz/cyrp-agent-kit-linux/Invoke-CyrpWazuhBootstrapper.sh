#!/usr/bin/env bash
set -euo pipefail

BACKEND_BASE_URL=""
ENROLLMENT_CODE=""
PACKAGE_PATH=""
FORCE_REENROLL=0
CONNECTION_TIMEOUT_SECONDS=180
AUTO_INSTALL_AGENT=0
WAZUH_AGENT_VERSION=""

usage() {
  cat <<'USAGE'
Usage:
  sudo bash Invoke-CyrpWazuhBootstrapper.sh --backend-base-url URL --enrollment-code CODE [--package-path FILE] [--auto-install-agent] [--wazuh-agent-version VERSION] [--force-reenroll]

Options:
  --backend-base-url URL        CYRP API base URL, for example http://192.168.1.10:3001/api/v1
  --enrollment-code CODE        One-time CYRP enrollment code from User Portal
  --package-path FILE           Optional local Wazuh Linux package (.deb or .rpm)
  --auto-install-agent          If wazuh-agent is not installed, install it from the official Wazuh repo
                                 (requires the endpoint to reach packages.wazuh.com)
  --wazuh-agent-version VERSION Pin/downgrade wazuh-agent to the manager-compatible package version
  --force-reenroll              Replace an existing different Wazuh identity intentionally
  --connection-timeout SECONDS  Wait time for Wazuh manager connection, default 180
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --backend-base-url)
      BACKEND_BASE_URL="${2:-}"; shift 2 ;;
    --enrollment-code)
      ENROLLMENT_CODE="${2:-}"; shift 2 ;;
    --package-path)
      PACKAGE_PATH="${2:-}"; shift 2 ;;
    --auto-install-agent)
      AUTO_INSTALL_AGENT=1; shift ;;
    --wazuh-agent-version)
      WAZUH_AGENT_VERSION="${2:-}"; shift 2 ;;
    --force-reenroll)
      FORCE_REENROLL=1; shift ;;
    --connection-timeout)
      CONNECTION_TIMEOUT_SECONDS="${2:-180}"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run this script with sudo/root." >&2
  exit 1
fi

if [[ -z "$BACKEND_BASE_URL" ]]; then
  echo "--backend-base-url is required." >&2
  exit 1
fi

if [[ -z "$ENROLLMENT_CODE" ]]; then
  read -r -p "Enter the one-time CYRP enrollment code: " ENROLLMENT_CODE
fi

ENROLLMENT_CODE="$(printf '%s' "$ENROLLMENT_CODE" | tr '[:lower:]' '[:upper:]' | xargs)"

if [[ -z "$ENROLLMENT_CODE" ]]; then
  echo "Enrollment code cannot be empty." >&2
  exit 1
fi

command -v python3 >/dev/null 2>&1 || { echo "python3 is required." >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALLER="$SCRIPT_DIR/Install-CyrpWazuhFromEnrollmentFile.sh"

if [[ ! -f "$INSTALLER" ]]; then
  echo "Missing installer component: $INSTALLER" >&2
  exit 1
fi

STATE_DIR="/var/lib/cyrp/state"
PENDING_DIR="/var/lib/cyrp/pending"
mkdir -p "$STATE_DIR" "$PENDING_DIR"
chmod 700 /var/lib/cyrp "$STATE_DIR" "$PENDING_DIR" 2>/dev/null || true

INSTALLATION_ID_FILE="$STATE_DIR/installation-id.txt"

if [[ -f "$INSTALLATION_ID_FILE" ]]; then
  INSTALLATION_ID="$(cat "$INSTALLATION_ID_FILE" | xargs)"
else
  INSTALLATION_ID="$(python3 - <<'PY'
import uuid
print(uuid.uuid4())
PY
)"
  printf '%s\n' "$INSTALLATION_ID" > "$INSTALLATION_ID_FILE"
  chmod 600 "$INSTALLATION_ID_FILE"
fi

HOSTNAME_VALUE="$(hostname)"
ARCHITECTURE="$(uname -m)"
OS_NAME="$(. /etc/os-release 2>/dev/null && printf '%s' "${PRETTY_NAME:-Linux}")"

PENDING_FILE="$PENDING_DIR/wazuh-enrollment-pending.json"

echo "Requesting CYRP Device and Wazuh Agent enrollment..."

python3 - "$BACKEND_BASE_URL" "$ENROLLMENT_CODE" "$INSTALLATION_ID" "$HOSTNAME_VALUE" "$OS_NAME" "$ARCHITECTURE" "$PENDING_FILE" <<'PY'
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

backend_base_url, enrollment_code, installation_id, hostname, os_name, architecture, pending_file = sys.argv[1:8]

base = backend_base_url.rstrip("/")
candidates = [base + "/agents/enroll"]

if base.endswith("/api"):
    candidates.append(base + "/v1/agents/enroll")
elif not base.endswith("/api/v1"):
    candidates.append(base + "/api/v1/agents/enroll")

body = json.dumps({
    "enrollmentCode": enrollment_code,
    "installationId": installation_id,
    "hostname": hostname,
    "operatingSystem": os_name,
    "architecture": architecture,
    "agentVersion": "wazuh-linux-agentkit",
}).encode("utf-8")

last_error = None
response = None

for uri in dict.fromkeys(candidates):
    print(f"Trying CYRP enrollment endpoint: {uri}", flush=True)
    request = urllib.request.Request(
        uri,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=30) as r:
            response = json.loads(r.read().decode("utf-8"))
            break
    except urllib.error.HTTPError as exc:
        last_error = exc
        if exc.code in (404, 405):
            print(f"Endpoint was not accepted ({exc.code}). Trying next candidate...", flush=True)
            continue
        detail = exc.read().decode("utf-8", "replace")
        raise SystemExit(f"CYRP enrollment failed with HTTP {exc.code}: {detail}") from exc
    except Exception as exc:
        last_error = exc
        raise

if response is None:
    raise SystemExit(f"CYRP enrollment failed: {last_error}")

required = [
    response.get("deviceId"),
    response.get("agentToken"),
    response.get("wazuh", {}).get("agentId"),
    response.get("wazuh", {}).get("agentName"),
    response.get("wazuh", {}).get("clientKey"),
    response.get("wazuh", {}).get("managerAddress"),
    response.get("wazuh", {}).get("managerPort"),
    response.get("wazuh", {}).get("protocol"),
]

if any(
    value is None or
    (isinstance(value, str) and not value.strip())
    for value in required
):
    raise SystemExit("The CYRP enrollment response is incomplete or contains an empty Wazuh client key.")

enrollment = {
    "deviceId": str(response["deviceId"]),
    "installationId": installation_id,
    "agentId": str(response["wazuh"]["agentId"]),
    "agentName": str(response["wazuh"]["agentName"]),
    "managerAddress": str(response["wazuh"]["managerAddress"]),
    "managerPort": int(response["wazuh"]["managerPort"]),
    "protocol": str(response["wazuh"]["protocol"]).lower(),
    "agentToken": str(response["agentToken"]),
    "clientKey": str(response["wazuh"]["clientKey"]),
}

target = Path(pending_file)
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(enrollment, indent=2), encoding="utf-8")
target.chmod(0o600)
print(target)
PY

DEVICE_ID="$(python3 - "$PENDING_FILE" <<'PY'
import json, sys
print(json.load(open(sys.argv[1], encoding="utf-8"))["deviceId"])
PY
)"

FINAL_PENDING_FILE="$PENDING_DIR/wazuh-enrollment-$DEVICE_ID.json"
mv "$PENDING_FILE" "$FINAL_PENDING_FILE"
chmod 600 "$FINAL_PENDING_FILE"

INSTALL_ARGS=(--enrollment-file "$FINAL_PENDING_FILE" --connection-timeout "$CONNECTION_TIMEOUT_SECONDS")

if [[ -n "$PACKAGE_PATH" ]]; then
  INSTALL_ARGS+=(--package-path "$PACKAGE_PATH")
fi

if [[ "$AUTO_INSTALL_AGENT" -eq 1 ]]; then
  INSTALL_ARGS+=(--auto-install-agent)
fi

if [[ -n "$WAZUH_AGENT_VERSION" ]]; then
  INSTALL_ARGS+=(--wazuh-agent-version "$WAZUH_AGENT_VERSION")
fi

if [[ "$FORCE_REENROLL" -eq 1 ]]; then
  INSTALL_ARGS+=(--force-reenroll)
fi

echo "Created CYRP/Wazuh enrollment for device $DEVICE_ID. Installing/configuring endpoint..."

if ! bash "$INSTALLER" "${INSTALL_ARGS[@]}"; then
  echo "Enrollment was created, but endpoint configuration failed." >&2
  printf 'Retry with: sudo bash %q' "$INSTALLER" >&2
  printf ' %q' "${INSTALL_ARGS[@]}" >&2
  printf '\n' >&2
  exit 1
fi
