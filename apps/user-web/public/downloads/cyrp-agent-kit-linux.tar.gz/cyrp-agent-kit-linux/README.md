# CYRP Agent Kit for Linux

This kit enrolls a Linux endpoint into CYRP/Wazuh using a one-time enrollment code from User Portal.

Supported target: Linux with the official Wazuh Agent layout under `/var/ossec`. Service control may use systemd, SysV init, or `/var/ossec/bin/wazuh-control`.

## Recommended command from User Portal

```bash
cd ~/Downloads
tar -xzf cyrp-agent-kit-linux.tar.gz
sudo bash ./cyrp-agent-kit-linux/Invoke-CyrpWazuhBootstrapper.sh \
  --backend-base-url "http://<CYRP_API_HOST>:3001/api/v1" \
  --enrollment-code "<ONE_TIME_CODE>" \
  --auto-install-agent \
  --wazuh-agent-version "4.9.2-1"
```

`--auto-install-agent` installs wazuh-agent from the official Wazuh repository (packages.wazuh.com) when it is
not already present. This requires the endpoint to have outbound internet access to that host. Skip this flag
if the endpoint has no internet access and wazuh-agent is already installed by other means (golden image,
config management, etc.).

If you'd rather install from a local package instead of the internet, either install Wazuh Agent first or pass a local package:

```bash
sudo bash ./cyrp-agent-kit-linux/Invoke-CyrpWazuhBootstrapper.sh \
  --backend-base-url "http://<CYRP_API_HOST>:3001/api/v1" \
  --enrollment-code "<ONE_TIME_CODE>" \
  --package-path "./wazuh-agent.deb"
```

For RPM based distributions:

```bash
sudo bash ./cyrp-agent-kit-linux/Invoke-CyrpWazuhBootstrapper.sh \
  --backend-base-url "http://<CYRP_API_HOST>:3001/api/v1" \
  --enrollment-code "<ONE_TIME_CODE>" \
  --package-path "./wazuh-agent.rpm"
```

## Important behavior

- The endpoint does not receive Wazuh API or Indexer credentials.
- The script stores a stable installation id at `/var/lib/cyrp/state/installation-id.txt`.
- The agent metadata sent to CYRP uses `agentVersion = wazuh-linux-agentkit`.
- Wazuh automatic enrollment is explicitly disabled in `/var/ossec/etc/ossec.conf`.
- Existing `/var/ossec/etc/client.keys` is not replaced unless `--force-reenroll` is provided.
- On configuration failure, the pending enrollment file is retained under `/var/lib/cyrp/pending/`.

## Verify

```bash
sudo bash ./cyrp-agent-kit-linux/Test-CyrpWazuhAgent.sh
```

## Manager compatibility

This CYRP deployment pins Linux endpoints to `wazuh-agent=4.9.2-1` so the endpoint package does not become newer than the Wazuh Manager. Change the generated command only after the Manager is upgraded and the CYRP portal is updated to the matching package version.

## Client key import behavior

The kit reads the top-level `clientKey` from the pending enrollment JSON, validates that its decoded Agent ID and Agent name match the enrollment response, and imports it non-interactively using:

```bash
printf 'y\n' | /var/ossec/bin/manage_agents -i "$CLIENT_KEY"
```

`clientKey` is base64, while `/var/ossec/etc/client.keys` contains the decoded line. The installer compares decoded values and restores the previous `client.keys` backup if import or verification fails. Users do not need to display or copy the secret key manually.
