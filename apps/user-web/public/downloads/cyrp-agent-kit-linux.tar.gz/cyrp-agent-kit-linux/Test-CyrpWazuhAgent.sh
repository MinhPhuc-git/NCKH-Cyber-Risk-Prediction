#!/usr/bin/env bash
set -euo pipefail

EXPECTED_AGENT_ID=""
EXPECTED_MANAGER_ADDRESS=""
EXPECTED_MANAGER_PORT="1514"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --expected-agent-id)
      EXPECTED_AGENT_ID="${2:-}"; shift 2 ;;
    --expected-manager-address)
      EXPECTED_MANAGER_ADDRESS="${2:-}"; shift 2 ;;
    --expected-manager-port)
      EXPECTED_MANAGER_PORT="${2:-1514}"; shift 2 ;;
    -h|--help)
      echo "Usage: sudo bash Test-CyrpWazuhAgent.sh [--expected-agent-id ID] [--expected-manager-address HOST] [--expected-manager-port PORT]"
      exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done

if [[ ! -f /var/ossec/etc/ossec.conf ]]; then
  echo "Wazuh Agent ossec.conf was not found." >&2
  exit 1
fi

if [[ ! -f /var/ossec/etc/client.keys ]]; then
  echo "Wazuh Agent client.keys was not found." >&2
  exit 1
fi

SERVICE_MODE=""
SERVICE_NAME=""

if command -v systemctl >/dev/null 2>&1; then
  systemctl daemon-reload >/dev/null 2>&1 || true
fi

if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files --type=service 2>/dev/null | grep -q '^wazuh-agent\.service'; then
  SERVICE_MODE="systemd"
  SERVICE_NAME="wazuh-agent"
elif command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files --type=service 2>/dev/null | grep -q '^wazuh\.service'; then
  SERVICE_MODE="systemd"
  SERVICE_NAME="wazuh"
elif [[ -x /etc/init.d/wazuh-agent ]]; then
  SERVICE_MODE="sysv"
  SERVICE_NAME="wazuh-agent"
elif [[ -x /etc/init.d/wazuh ]]; then
  SERVICE_MODE="sysv"
  SERVICE_NAME="wazuh"
elif [[ -x /var/ossec/bin/wazuh-control ]]; then
  SERVICE_MODE="control"
  SERVICE_NAME="wazuh-control"
else
  echo "No supported Wazuh Agent service controller was found." >&2
  exit 1
fi

agent_is_active() {
  case "$SERVICE_MODE" in
    systemd) systemctl is-active --quiet "$SERVICE_NAME" ;;
    sysv)
      "/etc/init.d/$SERVICE_NAME" status >/dev/null 2>&1 ||
        /var/ossec/bin/wazuh-control status 2>/dev/null | grep -q 'wazuh-agentd is running'
      ;;
    control)
      /var/ossec/bin/wazuh-control status 2>/dev/null | grep -q 'wazuh-agentd is running'
      ;;
  esac
}

read -r AGENT_ID AGENT_NAME _ < /var/ossec/etc/client.keys

MANAGER_ADDRESS="$(python3 - <<'PY'
import re
from pathlib import Path
text = Path('/var/ossec/etc/ossec.conf').read_text(errors='replace')
m = re.search(r'<client\b[^>]*>.*?<address>(.*?)</address>', text, flags=re.I|re.S)
print(m.group(1).strip() if m else '')
PY
)"

MANAGER_PORT="$(python3 - <<'PY'
import re
from pathlib import Path
text = Path('/var/ossec/etc/ossec.conf').read_text(errors='replace')
m = re.search(r'<client\b[^>]*>.*?<port>(.*?)</port>', text, flags=re.I|re.S)
print(m.group(1).strip() if m else '')
PY
)"

CONNECTED=0
LATEST_ERROR=""
if [[ -f /var/ossec/logs/ossec.log ]]; then
  if tail -n 300 /var/ossec/logs/ossec.log | grep -qi 'Connected to the server'; then
    CONNECTED=1
  fi
  LATEST_ERROR="$(tail -n 300 /var/ossec/logs/ossec.log | grep -Ei 'Unable to connect|Authentication error|Wrong key|corrupt payload|Invalid key' | tail -n 1 || true)"
fi

cat <<EOF
ServiceController: $SERVICE_MODE
ServiceName: $SERVICE_NAME
ServiceStatus: $(if agent_is_active; then echo active; else echo inactive; fi)
AgentId: $AGENT_ID
AgentName: $AGENT_NAME
ManagerAddress: $MANAGER_ADDRESS
ManagerPort: $MANAGER_PORT
Connected: $CONNECTED
LatestErrorLine: $LATEST_ERROR
EOF

if ! agent_is_active; then
  echo "Wazuh Agent service is not running." >&2
  exit 1
fi

if [[ -n "$EXPECTED_AGENT_ID" && "$AGENT_ID" != "$EXPECTED_AGENT_ID" ]]; then
  echo "Expected Agent ID $EXPECTED_AGENT_ID, but found $AGENT_ID." >&2
  exit 1
fi

if [[ -n "$EXPECTED_MANAGER_ADDRESS" && "$MANAGER_ADDRESS" != "$EXPECTED_MANAGER_ADDRESS" ]]; then
  echo "Expected manager $EXPECTED_MANAGER_ADDRESS, but found $MANAGER_ADDRESS." >&2
  exit 1
fi

if [[ -n "$EXPECTED_MANAGER_PORT" && "$MANAGER_PORT" != "$EXPECTED_MANAGER_PORT" ]]; then
  echo "Expected manager port $EXPECTED_MANAGER_PORT, but found $MANAGER_PORT." >&2
  exit 1
fi

if [[ "$CONNECTED" -ne 1 ]]; then
  echo "No successful Wazuh manager connection was found in the recent agent log." >&2
  exit 1
fi
